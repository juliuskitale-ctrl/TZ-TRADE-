# TZ Trade Hub — production-ready MVP

A practical Tanzania-focused B2B/B2C marketplace for:

- Electronics
- Spare parts
- Fashion / wholesale
- Used & refurbished goods
- Construction / hardware
- Local in-stock products
- China/Dubai import pre-orders

## What is included

- Responsive public marketplace
- Swahili / English UI toggle
- Local stock vs import pre-order filters
- Product search
- Product catalogue API
- Vendor registration/login
- Store/vendor data model
- Orders
- Escrow state model
- Financial ledger
- Subscriptions
- Featured listings
- Messaging schema
- ClickPesa integration adapter
- Payment webhook endpoint
- PostgreSQL schema
- Docker deployment
- Render deployment manifest

## 1. Local test

Requirements: Node.js 22+ and Docker.

```bash
cp .env.example .env
docker compose up -d db
npm install
npm run db:init
npm start
```

Open:

http://localhost:8080

## 2. Deploy to the public internet

### Render

1. Create a GitHub repository.
2. Upload this project.
3. Create a Render account.
4. Connect the GitHub repository.
5. Render can use `render.yaml`.
6. Set the production payment variables only after the payment provider account is approved.
7. Run the database initialization once:

```bash
node src/init-db.js
```

The application exposes:

`GET /api/health`

for the platform health check.

## 3. Payment production setup

The MVP starts with:

`PAYMENT_PROVIDER=mock`

Do NOT treat mock payments as real money.

For production, obtain merchant/API credentials from your licensed payment provider and set:

- PAYMENT_PROVIDER=clickpesa
- CLICKPESA_CLIENT_ID
- CLICKPESA_CLIENT_SECRET
- CLICKPESA_CHECKSUM_SECRET

The ClickPesa adapter is intentionally isolated in `src/payments/clickpesa.js`.

Configure your provider webhook to:

`POST https://YOUR-DOMAIN/api/payments/webhooks/clickpesa`

The server verifies the webhook checksum when a checksum secret is configured and uses idempotency protection.

## 4. Important Tanzania compliance point

This software records payment/escrow state and settlement instructions. It is NOT a licence to operate a payment system.

Do not hold customer funds in an ordinary personal bank account or manually operate an unlicensed wallet. Use a licensed payment provider and obtain the required legal/regulatory approvals for the business model before taking public customer money.

## 5. First production checklist

- Register the company/business.
- Obtain appropriate tax/business registrations.
- Open a dedicated business settlement account.
- Complete PSP/gateway merchant onboarding.
- Configure verified domain and HTTPS.
- Replace mock payments.
- Configure production database backups.
- Configure privacy policy, terms, refunds and vendor agreement.
- Verify seller identity/business information.
- Add delivery partners.
- Add admin moderation.
- Enable monitoring and error logging.
- Perform payment/webhook tests before launch.

## API

- `GET /api/health`
- `GET /api/products`
- `GET /api/categories`
- `GET /api/stores`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/orders`
- `GET /api/orders/:id`
- `POST /api/payments/initiate`
- `POST /api/payments/webhooks/clickpesa`

## Security

Secrets are environment variables. Passwords are hashed. Webhooks support signature verification and duplicate-event protection. Financial records are append-only ledger entries.

This is a launchable MVP foundation, not a substitute for legal, payment-provider, security and operational certification.
