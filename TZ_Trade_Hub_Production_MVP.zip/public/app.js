let fulfillment = "";
let q = "";
let category = "";

const icons = {
  "electronics":"📱",
  "spare-parts":"🚗",
  "fashion":"👟",
  "used-refurbished":"💻",
  "construction-hardware":"🔧"
};

async function getJSON(url){
  const r = await fetch(url);
  if(!r.ok) throw new Error("Request failed");
  return r.json();
}

function money(n){
  return Number(n || 0).toLocaleString("en-TZ",{style:"currency",currency:"TZS",maximumFractionDigits:0});
}

async function loadCategories(){
  const cats = await getJSON("/api/categories");
  const box = document.querySelector("#categories");
  const select = document.querySelector("#category");
  box.innerHTML = "";
  cats.forEach(c=>{
    const b=document.createElement("button");
    b.className="cat";
    b.textContent=(icons[c.slug]||"🛍️")+" "+c.name_en;
    b.onclick=()=>{category=c.slug;select.value=category;loadProducts()};
    box.appendChild(b);
    const o=document.createElement("option");
    o.value=c.slug;o.textContent=c.name_en;select.appendChild(o);
  });
}

async function loadProducts(){
  const params=new URLSearchParams();
  if(q)params.set("q",q);
  if(fulfillment)params.set("fulfillment",fulfillment);
  if(category)params.set("category",category);
  const products=await getJSON("/api/products?"+params);
  document.querySelector("#count").textContent=`${products.length} products`;
  const box=document.querySelector("#products");
  box.innerHTML="";
  if(!products.length){box.innerHTML="<p>No products found yet. Sellers can add the first listings.</p>";return}
  products.forEach(p=>{
    const el=document.createElement("article");
    el.className="product";
    const local=p.fulfillment_type==="LOCAL_STOCK";
    const preorder=p.fulfillment_type==="IMPORT_PREORDER";
    el.innerHTML=`
      <div class="photo">${icons[p.category_name?.toLowerCase()]||"🛍️"}</div>
      <div class="pbody">
        <span class="badge">${local?"LOCAL STOCK":preorder?"IMPORT PRE-ORDER":"LOCAL + IMPORT"}</span>
        <h3>${escapeHTML(p.name_en)}</h3>
        <div class="store">${escapeHTML(p.store_name||"Seller")}</div>
        <div class="price">${money(p.price_tzs)}</div>
        <div class="origin">${escapeHTML(p.origin_country||"Tanzania")} · ${p.stock_quantity||0} available</div>
      </div>`;
    box.appendChild(el);
  });
}

function escapeHTML(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

document.querySelector("#searchBtn").onclick=()=>{q=document.querySelector("#q").value.trim();loadProducts()};
document.querySelector("#q").addEventListener("keydown",e=>{if(e.key==="Enter"){q=e.target.value.trim();loadProducts()}});
document.querySelector("#category").onchange=e=>{category=e.target.value;loadProducts()};
document.querySelectorAll(".choice").forEach(b=>b.onclick=()=>{
  fulfillment=b.dataset.filter;
  document.querySelectorAll(".choice").forEach(x=>x.classList.remove("active"));
  b.classList.add("active");loadProducts();
});
document.querySelector("#lang").onclick=()=>alert("Swahili/English UI is enabled. Product translation fields are supported by the API.");
document.querySelector("#sell").onclick=()=>alert("Seller registration API: POST /api/auth/register with role=SELLER");
document.querySelector("#vendorBtn").onclick=()=>alert("Seller registration API: POST /api/auth/register with role=SELLER");

Promise.all([loadCategories(),loadProducts()]).catch(e=>console.error(e));
