CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(255) UNIQUE,
  phone VARCHAR(30) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  preferred_language VARCHAR(5) DEFAULT 'sw',
  role VARCHAR(30) NOT NULL DEFAULT 'CUSTOMER',
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vendor_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vendor_type VARCHAR(30) NOT NULL,
  business_name VARCHAR(200) NOT NULL,
  business_registration_no VARCHAR(100),
  tin VARCHAR(100),
  verification_status VARCHAR(30) DEFAULT 'PENDING',
  rating NUMERIC(3,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS stores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendor_profiles(id) ON DELETE CASCADE,
  store_name VARCHAR(200) NOT NULL,
  slug VARCHAR(220) UNIQUE NOT NULL,
  description TEXT,
  region VARCHAR(100),
  district VARCHAR(100),
  is_featured BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID REFERENCES categories(id),
  name_en VARCHAR(150) NOT NULL,
  name_sw VARCHAR(150) NOT NULL,
  slug VARCHAR(180) UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  category_id UUID REFERENCES categories(id),
  name_en VARCHAR(255) NOT NULL,
  name_sw VARCHAR(255),
  slug VARCHAR(280) UNIQUE NOT NULL,
  description_en TEXT,
  description_sw TEXT,
  brand VARCHAR(150),
  product_condition VARCHAR(30) DEFAULT 'NEW',
  fulfillment_type VARCHAR(30) NOT NULL,
  origin_country VARCHAR(100) DEFAULT 'Tanzania',
  price_tzs NUMERIC(15,2),
  price_usd NUMERIC(15,2),
  minimum_order_quantity INTEGER DEFAULT 1,
  stock_quantity INTEGER DEFAULT 0,
  estimated_import_days INTEGER,
  image_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  is_featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number VARCHAR(40) UNIQUE NOT NULL,
  buyer_id UUID NOT NULL REFERENCES users(id),
  store_id UUID NOT NULL REFERENCES stores(id),
  fulfillment_type VARCHAR(30) NOT NULL,
  status VARCHAR(40) DEFAULT 'PENDING_PAYMENT',
  currency CHAR(3) DEFAULT 'TZS',
  subtotal NUMERIC(15,2) NOT NULL,
  shipping_fee NUMERIC(15,2) DEFAULT 0,
  platform_fee NUMERIC(15,2) DEFAULT 0,
  total_amount NUMERIC(15,2) NOT NULL,
  delivery_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  unit_price NUMERIC(15,2) NOT NULL,
  total_price NUMERIC(15,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS payment_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES orders(id),
  buyer_id UUID REFERENCES users(id),
  provider VARCHAR(50) NOT NULL,
  provider_transaction_id VARCHAR(255),
  payment_method VARCHAR(50),
  phone_number VARCHAR(30),
  currency CHAR(3) DEFAULT 'TZS',
  amount NUMERIC(15,2) NOT NULL,
  status VARCHAR(30) DEFAULT 'PENDING',
  raw_reference VARCHAR(255),
  raw_payload JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_payment_provider_tx
ON payment_transactions(provider, provider_transaction_id)
WHERE provider_transaction_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS webhook_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider VARCHAR(50) NOT NULL,
  event_key VARCHAR(255) NOT NULL,
  payload JSONB NOT NULL,
  received_at TIMESTAMPTZ DEFAULT NOW(),
  processed_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_webhook_event
ON webhook_events(provider, event_key);

CREATE TABLE IF NOT EXISTS escrow_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID UNIQUE NOT NULL REFERENCES orders(id),
  payment_transaction_id UUID REFERENCES payment_transactions(id),
  amount NUMERIC(15,2) NOT NULL,
  currency CHAR(3) DEFAULT 'TZS',
  status VARCHAR(30) DEFAULT 'PENDING',
  held_at TIMESTAMPTZ,
  release_at TIMESTAMPTZ,
  released_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  escrow_id UUID REFERENCES escrow_transactions(id),
  order_id UUID REFERENCES orders(id),
  entry_type VARCHAR(40) NOT NULL,
  amount NUMERIC(15,2) NOT NULL,
  currency CHAR(3) DEFAULT 'TZS',
  reference VARCHAR(255),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS subscription_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  price_tzs NUMERIC(15,2) NOT NULL,
  duration_days INTEGER NOT NULL,
  max_products INTEGER,
  verified_badge BOOLEAN DEFAULT FALSE,
  featured_listing_credits INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS vendor_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id UUID NOT NULL REFERENCES vendor_profiles(id),
  plan_id UUID NOT NULL REFERENCES subscription_plans(id),
  status VARCHAR(30) DEFAULT 'ACTIVE',
  starts_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS commission_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES categories(id),
  vendor_type VARCHAR(40),
  commission_percent NUMERIC(5,2) NOT NULL CHECK(commission_percent >= 2 AND commission_percent <= 7),
  active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS featured_listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID REFERENCES products(id),
  store_id UUID REFERENCES stores(id),
  placement VARCHAR(50),
  budget_tzs NUMERIC(15,2),
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  impressions INTEGER DEFAULT 0,
  clicks INTEGER DEFAULT 0,
  status VARCHAR(30) DEFAULT 'PENDING'
);

CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID NOT NULL REFERENCES users(id),
  seller_id UUID NOT NULL REFERENCES users(id),
  product_id UUID REFERENCES products(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id),
  message_text TEXT NOT NULL,
  language VARCHAR(5),
  translated_text TEXT,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO categories(name_en,name_sw,slug) VALUES
('Electronics','Elektroniki','electronics'),
('Spare Parts','Vipuri','spare-parts'),
('Fashion & Wholesale','Mavazi & Jumla','fashion'),
('Used & Refurbished','Vilivyotumika & Refurbished','used-refurbished'),
('Construction & Hardware','Ujenzi & Hardware','construction-hardware')
ON CONFLICT(slug) DO NOTHING;

INSERT INTO subscription_plans(name,price_tzs,duration_days,max_products,verified_badge,featured_listing_credits)
SELECT 'Free',0,365,10,false,0
WHERE NOT EXISTS (SELECT 1 FROM subscription_plans WHERE name='Free');

INSERT INTO subscription_plans(name,price_tzs,duration_days,max_products,verified_badge,featured_listing_credits)
SELECT 'Verified Importer',50000,30,500,true,5
WHERE NOT EXISTS (SELECT 1 FROM subscription_plans WHERE name='Verified Importer');
