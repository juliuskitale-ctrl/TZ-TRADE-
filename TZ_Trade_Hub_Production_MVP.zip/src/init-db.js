require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { pool } = require("./db");

(async () => {
  const sql = fs.readFileSync(path.join(__dirname, "..", "sql", "schema.sql"), "utf8");
  await pool.query(sql);
  console.log("Database initialized.");
  await pool.end();
})().catch(async (err) => {
  console.error(err);
  await pool.end();
  process.exit(1);
});
