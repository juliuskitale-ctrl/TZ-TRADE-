require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const path = require("path");
const crypto = require("crypto");
const { pool } = require("./db");
const { hashPassword, comparePassword, signUser, requireAuth } = require("./auth");
const { verifyChecksum, createCheckout } = require("./payments/clickpesa");

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN === "*" ? true : (process.env.CORS_ORIGIN || true) }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "..", "public")));

function orderNumber() {
  return `TZ-${new Date().toISOString().slice(0,10).replaceAll("-","")}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true, service: "tztradehub", time: new Date().toISOString() });
  } catch {
    res.status(503).json({ ok: false });
  }
});

app.get("/api/categories", async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM categories ORDER BY name_en");
  res.json(rows);
});

app.get("/api/products", async (req, res) => {
  const { q = "", fulfillment = "", category = "" } = req.query;
  const values = [];
  const where = ["p.is_active = true"];
  if (q) {
    values.push(`%${q}%`);
    where.push(`(p.name_en ILIKE $${values.length} OR p.name_sw ILIKE $${values.length} OR p.brand ILIKE $${values.length})`);
  }
  if (fulfillment && ["LOCAL_STOCK","IMPORT_PREORDER","BOTH"].includes(fulfillment)) {
    values.push(fulfillment);
    where.push(`p.fulfillment_type = $${values.length}`);
  }
  if (category) {
    values.push(category);
    where.push(`c.slug = $${values.length}`);
  }
  const { rows } = await pool.query(`
    SELECT p.*, s.store_name, s.slug AS store_slug, c.name_en AS category_name
    FROM products p
    JOIN stores s ON s.id=p.store_id
    LEFT JOIN categories c ON c.id=p.category_id
    WHERE ${where.join(" AND ")}
    ORDER BY p.is_featured DESC, p.created_at DESC
    LIMIT 100
  `, values);
  res.json(rows);
});

app.get("/api/stores", async (req, res) => {
  const { rows } = await pool.query(`
    SELECT s.*, v.vendor_type, v.verification_status
    FROM stores s JOIN vendor_profiles v ON v.id=s.vendor_id
    WHERE s.is_active=true ORDER BY s.is_featured DESC, s.created_at DESC LIMIT 100
  `);
  res.json(rows);
});

app.post("/api/auth/register", async (req, res) => {
  const { fullName, phone, email, password, role = "CUSTOMER" } = req.body;
  if (!fullName || !phone || !password) return res.status(400).json({ error: "Full name, phone and password are required." });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });
  try {
    const hash = await hashPassword(password);
    const { rows } = await pool.query(
      `INSERT INTO users(full_name,phone,email,password_hash,role) VALUES($1,$2,$3,$4,$5) RETURNING id,full_name,phone,email,role`,
      [fullName, phone, email || null, hash, role === "SELLER" ? "SELLER" : "CUSTOMER"]
    );
    const user = rows[0];
    res.status(201).json({ user, token: signUser(user) });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "Phone or email already registered." });
    res.status(500).json({ error: "Registration failed." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { phone, password } = req.body;
  const { rows } = await pool.query("SELECT * FROM users WHERE phone=$1", [phone]);
  if (!rows[0] || !(await comparePassword(password, rows[0].password_hash))) {
    return res.status(401).json({ error: "Invalid credentials." });
  }
  const u = rows[0];
  res.json({
    user: { id: u.id, fullName: u.full_name, phone: u.phone, email: u.email, role: u.role },
    token: signUser(u)
  });
});

app.post("/api/orders", requireAuth, async (req, res) => {
  const { storeId, items, fulfillmentType = "LOCAL_STOCK", deliveryAddress = "" } = req.body;
  if (!storeId || !Array.isArray(items) || !items.length) return res.status(400).json({ error: "Store and items are required." });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const ids = items.map(x => x.productId);
    const { rows: products } = await client.query(
      `SELECT id,store_id,price_tzs,stock_quantity FROM products WHERE id = ANY($1::uuid[]) FOR UPDATE`,
      [ids]
    );
    if (products.length !== ids.length) throw new Error("One or more products do not exist.");

    let subtotal = 0;
    for (const item of items) {
      const p = products.find(x => x.id === item.productId);
      const qty = Number(item.quantity);
      if (!Number.isInteger(qty) || qty < 1) throw new Error("Invalid quantity.");
      if (p.store_id !== storeId) throw new Error("All MVP order items must belong to the same store.");
      if (fulfillmentType === "LOCAL_STOCK" && p.stock_quantity < qty) throw new Error("Insufficient stock.");
      subtotal += Number(p.price_tzs) * qty;
    }

    const commission = Number((subtotal * 0.05).toFixed(2));
    const total = subtotal;

    const order = await client.query(
      `INSERT INTO orders(order_number,buyer_id,store_id,fulfillment_type,status,subtotal,platform_fee,total_amount,delivery_address)
       VALUES($1,$2,$3,$4,'PENDING_PAYMENT',$5,$6,$7,$8) RETURNING *`,
      [orderNumber(), req.user.sub, storeId, fulfillmentType, subtotal, commission, total, deliveryAddress]
    );

    for (const item of items) {
      const p = products.find(x => x.id === item.productId);
      const qty = Number(item.quantity);
      await client.query(
        `INSERT INTO order_items(order_id,product_id,quantity,unit_price,total_price) VALUES($1,$2,$3,$4,$5)`,
        [order.rows[0].id, p.id, qty, p.price_tzs, Number(p.price_tzs) * qty]
      );
      if (fulfillmentType === "LOCAL_STOCK") {
        await client.query("UPDATE products SET stock_quantity=stock_quantity-$1 WHERE id=$2", [qty, p.id]);
      }
    }

    await client.query(
      `INSERT INTO escrow_transactions(order_id,amount,currency,status) VALUES($1,$2,'TZS','PENDING')`,
      [order.rows[0].id, total]
    );

    await client.query("COMMIT");
    res.status(201).json({ order: order.rows[0] });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: e.message || "Could not create order." });
  } finally {
    client.release();
  }
});

app.get("/api/orders/:id", requireAuth, async (req, res) => {
  const { rows } = await pool.query(`
    SELECT o.*, e.status AS escrow_status
    FROM orders o LEFT JOIN escrow_transactions e ON e.order_id=o.id
    WHERE o.id=$1 AND o.buyer_id=$2
  `, [req.params.id, req.user.sub]);
  if (!rows[0]) return res.status(404).json({ error: "Order not found." });
  res.json(rows[0]);
});

app.post("/api/payments/initiate", requireAuth, async (req, res) => {
  const { orderId, phoneNumber } = req.body;
  const { rows } = await pool.query(
    `SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON u.id=o.buyer_id WHERE o.id=$1 AND o.buyer_id=$2`,
    [orderId, req.user.sub]
  );
  if (!rows[0]) return res.status(404).json({ error: "Order not found." });
  const o = rows[0];

  try {
    const checkout = await createCheckout({
      amount: String(o.total_amount),
      orderReference: o.order_number,
      customerName: o.full_name,
      customerEmail: o.email || "",
      customerPhone: phoneNumber || o.phone,
      description: `TZ Trade Hub order ${o.order_number}`
    });
    res.json({ provider: checkout.provider || "clickpesa", checkoutUrl: checkout.checkoutUrl });
  } catch (e) {
    res.status(503).json({ error: e.message });
  }
});

app.post("/api/payments/webhooks/clickpesa", async (req, res) => {
  const payload = req.body || {};
  const eventKey = String(payload.id || payload.transactionId || payload.orderReference || crypto.randomUUID());

  try {
    const checksum = req.headers["x-checksum"] || payload.checksum;
    if (process.env.CLICKPESA_CHECKSUM_SECRET) {
      if (!verifyChecksum(payload, checksum, process.env.CLICKPESA_CHECKSUM_SECRET)) {
        return res.status(401).json({ error: "Invalid checksum" });
      }
    }

    const inserted = await pool.query(
      `INSERT INTO webhook_events(provider,event_key,payload) VALUES('clickpesa',$1,$2)
       ON CONFLICT(provider,event_key) DO NOTHING RETURNING id`,
      [eventKey, payload]
    );

    if (!inserted.rows.length) return res.json({ received: true, duplicate: true });

    const reference = payload.orderReference || payload.order_reference;
    const status = String(payload.status || payload.event || "").toUpperCase();
    if (reference) {
      const { rows: orders } = await pool.query("SELECT * FROM orders WHERE order_number=$1", [reference]);
      if (orders[0]) {
        let paymentStatus = status.includes("FAIL") ? "FAILED" : status.includes("RECEIV") || status === "SUCCESS" ? "SUCCESS" : "PROCESSING";
        await pool.query(
          `INSERT INTO payment_transactions(order_id,buyer_id,provider,provider_transaction_id,payment_method,currency,amount,status,raw_payload,completed_at)
           VALUES($1,$2,'clickpesa',$3,$4,$5,$6,$7,$8,$9)`,
          [orders[0].id, orders[0].buyer_id, String(payload.id || payload.transactionId || ""), payload.channel || payload.paymentMethod || null,
           payload.currency || "TZS", Number(payload.amount || payload.collectedAmount || orders[0].total_amount), paymentStatus, payload,
           paymentStatus === "SUCCESS" ? new Date() : null]
        );
        if (paymentStatus === "SUCCESS") {
          await pool.query("UPDATE orders SET status='PAID', updated_at=NOW() WHERE id=$1", [orders[0].id]);
          await pool.query("UPDATE escrow_transactions SET status='HELD', held_at=NOW() WHERE order_id=$1", [orders[0].id]);
          await pool.query(
            `INSERT INTO ledger_entries(escrow_id,order_id,entry_type,amount,currency,reference)
             SELECT id, $1, 'CUSTOMER_PAYMENT', amount, currency, $2 FROM escrow_transactions WHERE order_id=$1
             AND NOT EXISTS (SELECT 1 FROM ledger_entries WHERE order_id=$1 AND entry_type='CUSTOMER_PAYMENT')`,
            [orders[0].id, eventKey]
          );
        }
      }
    }

    await pool.query("UPDATE webhook_events SET processed_at=NOW() WHERE id=$1", [inserted.rows[0].id]);
    res.json({ received: true });
  } catch (e) {
    res.status(500).json({ error: "Webhook processing failed." });
  }
});

app.post("/api/orders/:id/confirm-delivery", requireAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows } = await client.query(
      `SELECT o.*, e.id escrow_id, e.amount, e.currency FROM orders o JOIN escrow_transactions e ON e.order_id=o.id
       WHERE o.id=$1 AND o.buyer_id=$2 FOR UPDATE`,
      [req.params.id, req.user.sub]
    );
    if (!rows[0]) return res.status(404).json({ error: "Order not found." });
    if (rows[0].status !== "PAID" && rows[0].status !== "SHIPPED" && rows[0].status !== "DELIVERED") {
      throw new Error("Order is not ready for delivery confirmation.");
    }

    await client.query("UPDATE orders SET status='COMPLETED', updated_at=NOW() WHERE id=$1", [req.params.id]);
    await client.query("UPDATE escrow_transactions SET status='RELEASED', released_at=NOW() WHERE order_id=$1", [req.params.id]);
    await client.query(
      `INSERT INTO ledger_entries(escrow_id,order_id,entry_type,amount,currency,reference)
       VALUES($1,$2,'SELLER_PAYOUT',$3,$4,$5)`,
      [rows[0].escrow_id, req.params.id, Number(rows[0].amount) - Number(rows[0].platform_fee || 0), rows[0].currency, "buyer-confirmed-delivery"]
    );
    await client.query("COMMIT");
    res.json({ ok: true, status: "COMPLETED" });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: e.message });
  } finally {
    client.release();
  }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`TZ Trade Hub running on port ${port}`));
