const crypto = require("crypto");

function stablePayload(payload) {
  const copy = { ...payload };
  delete copy.checksum;
  delete copy.checksumMethod;
  return copy;
}

/*
 * Keep provider-specific signing here. ClickPesa documents checksum-signed
 * requests/webhooks. The exact canonicalization must follow the current
 * provider account configuration and documentation.
 */
function verifyChecksum(payload, providedChecksum, secret) {
  if (!secret || !providedChecksum) return false;
  const canonical = JSON.stringify(stablePayload(payload));
  const expected = crypto.createHmac("sha256", secret).update(canonical).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(providedChecksum));
}

async function createCheckout({ amount, orderReference, customerName, customerEmail, customerPhone, description }) {
  if (!process.env.CLICKPESA_CLIENT_ID || !process.env.CLICKPESA_CLIENT_SECRET) {
    return { provider: "mock", checkoutUrl: `/checkout/mock?order=${encodeURIComponent(orderReference)}` };
  }

  // Production implementation should obtain an access token using the
  // current ClickPesa API credentials, then call the hosted checkout endpoint.
  // Kept isolated so the provider contract can be updated without touching
  // order/escrow logic.
  throw new Error("ClickPesa credentials detected: complete provider token/checksum configuration before enabling live payments.");
}

module.exports = { verifyChecksum, createCheckout };
